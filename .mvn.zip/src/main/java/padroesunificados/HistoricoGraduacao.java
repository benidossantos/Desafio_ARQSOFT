package padroesunificados;

public class HistoricoGraduacao implements Historico {

    public String emitir() {
        return "Histórico de Graduação";
    }
}
